
public class Principal {

	public static void main(String[] args) {
		A_G run = new A_G();
		run.constroi();
		run.info();
	}
}
